﻿CREATE TABLE [dbo].[BugTable]
(
	[BugId] INT NOT NULL PRIMARY KEY,
	[Bug Type] nvarchar (15) NOT NULL,
	[Class File Name] nvarchar (15) NOT NULL,
	[Method Name] nvarchar (15) NOT NULL,
	[Code Block] nvarchar (15) NOT NULL,
	[Line Number] INT NOT NULL,
)
